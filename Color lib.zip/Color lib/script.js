document.addEventListener("DOMContentLoaded", () => {
    let icon = document.querySelector(".navi");
    const categories = document.querySelector('.categories');

    function toggleMenu() {
        icon.addEventListener("click", () => {
            categories.classList.toggle("show-menu");
        });
    }

    toggleMenu();
});
const swiper = new Swiper('.swiper', {
    loop: true, // Enable infinite loop mode
    autoplay: {
        delay: 5000, // Delay between slides in milliseconds
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    effect: 'slide', // Effect can be 'fade', 'cube', 'coverflow', or 'flip'
});
